"""
PrintHub Agent  –  Cross-Platform USB Print Agent
Supports Windows (win32print / WMI) and macOS (CUPS / lp).

Firewall note: this agent makes OUTBOUND HTTP/HTTPS requests only.
No inbound ports are required on the workstation.
"""

import socket
import platform
import logging
import time
import os
import threading
import sys

_OS = platform.system()
_WIN32_AVAILABLE = False

if _OS == "Windows":
    try:
        import win32print
        _WIN32_AVAILABLE = True
    except ImportError:
        logging.warning("win32print not available — USB printing disabled on Windows")
elif _OS == "Darwin":
    try:
        from agent_macos import (
            check_printer_status as _macos_check,
            print_raw as _macos_print_raw,
            list_local_printers as _macos_list,
            _get_usb_port as _macos_get_port,
            print_direct as _macos_print_direct,
        )
    except ImportError:
        logging.error("agent_macos.py missing — macOS printing will fail")
else:
    logging.error(f"Unsupported OS: {_OS}")

from agent_config import load_config, save_config, restrict_config_permissions

# ── Logging setup (rotating file + console) ──────────────────────────────────
from logging.handlers import RotatingFileHandler

_log_dir = (
    r"C:\PrintHubAgent" if _OS == "Windows"
    else os.path.join(os.path.expanduser("~"), "Library", "Logs")
    if _OS == "Darwin"
    else os.path.join(os.path.expanduser("~"), ".printhub")
)
os.makedirs(_log_dir, exist_ok=True)

_log_file = os.path.join(_log_dir, "printhub_agent.log")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        RotatingFileHandler(_log_file, maxBytes=5 * 1024 * 1024, backupCount=3),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("PrintAgent")

# ── Requests with retry + security ───────────────────────────────────────────
try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    _session = requests.Session()
    _retry = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["GET", "POST"],
    )
    _adapter = HTTPAdapter(max_retries=_retry)
    _session.mount("http://", _adapter)
    _session.mount("https://", _adapter)
except ImportError:
    logger.critical("requests library not installed. Run: pip install requests")
    sys.exit(1)


def _http_get(url, params=None, timeout=10, verify=True):
    return _session.get(url, params=params, timeout=timeout, verify=verify)


def _http_post(url, params=None, json=None, timeout=10, verify=True):
    return _session.post(url, params=params, json=json, timeout=timeout, verify=verify)


# ── Configuration ─────────────────────────────────────────────────────────────
_config = load_config()
SERVER_URL: str = _config.get("server_url") or os.environ.get("SERVER_URL", "http://127.0.0.1:8000")
_TLS_VERIFY: bool = _config.get("tls_verify", True)


def ensure_registered():
    """
    Registers the agent with the server using the activation code saved by
    agent_setup.py.  Returns (agent_id, token, location_id) on success.
    Exits the process on unrecoverable failure.
    """
    config = load_config()
    global SERVER_URL, _TLS_VERIFY
    if config.get("server_url"):
        SERVER_URL = config["server_url"]
    _TLS_VERIFY = config.get("tls_verify", True)

    # Already registered
    if config.get("agent_id") and config.get("token"):
        logger.info(f"Credentials loaded: {config['agent_id']} → {SERVER_URL}")
        return config["agent_id"], config["token"], config.get("location_id", "")

    # Need to activate
    pending_code = config.get("pending_activation_code")
    if not pending_code:
        logger.critical("No credentials and no pending_activation_code found.")
        logger.critical("Run: python agent_setup.py --code YOUR_ACTIVATION_CODE --server http://SERVER_IP:8000")
        sys.exit(1)

    logger.info("Pending activation code found — attempting registration…")
    hostname = socket.gethostname()

    # Retry registration up to 5 times with exponential backoff
    for attempt in range(5):
        try:
            res = _http_post(
                f"{SERVER_URL}/agent/register",
                json={"activation_code": pending_code, "hostname": hostname},
                timeout=15,
                verify=_TLS_VERIFY,
            )
            if res.status_code == 200:
                data = res.json()
                new_config = {
                    "agent_id": data["agent_id"],
                    "token": data["token"],
                    "location_id": data["location_id"],
                    "server_url": SERVER_URL,
                    "tls_verify": _TLS_VERIFY,
                }
                save_config(new_config)
                restrict_config_permissions()
                logger.info(f"Registered successfully as {data['agent_id']}")
                return data["agent_id"], data["token"], data["location_id"]
            else:
                logger.error(f"Registration failed ({res.status_code}): {res.text}")
                if res.status_code in (400, 401, 403):
                    logger.critical("Invalid or already-used activation code. Get a new one from the dashboard.")
                    sys.exit(1)
        except requests.exceptions.SSLError as e:
            logger.error(f"TLS/SSL error: {e}")
            logger.error("If you're using a self-signed certificate, add  tls_verify: false  to agent_config.json")
            sys.exit(1)
        except requests.exceptions.ConnectionError as e:
            wait = 2 ** attempt
            logger.warning(f"Cannot reach {SERVER_URL} (attempt {attempt+1}/5). Retrying in {wait}s… ({e})")
            time.sleep(wait)

    logger.critical(f"Cannot reach server after 5 attempts. Check SERVER_URL and network connectivity.")
    sys.exit(1)


AGENT_ID, TOKEN, LOCATION_ID = ensure_registered()
POLL_INTERVAL = 5
HEARTBEAT_INTERVAL = 15

# ── Consecutive failure tracking for adaptive backoff ────────────────────────
_consec_errors = 0
_MAX_BACKOFF = 60  # seconds


def _backoff_sleep(success: bool):
    """Adapts poll delay: ramps up on repeated failures, resets on success."""
    global _consec_errors
    if success:
        _consec_errors = 0
        time.sleep(POLL_INTERVAL)
    else:
        _consec_errors += 1
        delay = min(POLL_INTERVAL * (2 ** min(_consec_errors, 4)), _MAX_BACKOFF)
        logger.info(f"Backing off for {delay}s (consecutive errors: {_consec_errors})")
        time.sleep(delay)


# ── OS dispatch wrappers ──────────────────────────────────────────────────────

def check_printer_status(printer_name: str) -> str:
    if _OS == "Darwin":
        return _macos_check(printer_name)

    if not _WIN32_AVAILABLE:
        return "Offline"

    # Layer 1: physical presence
    try:
        enumerated = {p[2].lower() for p in win32print.EnumPrinters(2)}
    except Exception as e:
        logger.error(f"EnumPrinters failed: {e}")
        return "Offline"

    if printer_name.lower() not in enumerated:
        logger.warning(f"'{printer_name}' not found in EnumPrinters")
        return "Offline"

    # Layer 2: WMI (optional — graceful if not installed)
    try:
        import pythoncom
        from wmi import WMI
        pythoncom.CoInitialize()
        try:
            c = WMI()
            wmi_printers = c.Win32_Printer(Name=printer_name)
            if wmi_printers:
                wp = wmi_printers[0]
                if getattr(wp, "WorkOffline", False):
                    return "Offline"
                p_status = getattr(wp, "PrinterStatus", 0)
                if p_status in (1, 2, 7):
                    return "Offline"
        finally:
            pythoncom.CoUninitialize()
    except ImportError:
        pass  # WMI not installed — skip
    except Exception as e:
        logger.debug(f"WMI check skipped: {e}")

    # Layer 3: win32print handle
    try:
        handle = win32print.OpenPrinter(printer_name)
        try:
            info = win32print.GetPrinter(handle, 2)
            status = info.get("Status", 0)
            attributes = info.get("Attributes", 0)
            logger.debug(f"'{printer_name}' Status=0x{status:08X} Attr=0x{attributes:08X}")

            if attributes & 0x00000400:  # WORK_OFFLINE attribute
                return "Offline"
            if status & 0x00000080:      # PRINTER_STATUS_OFFLINE
                return "Offline"
            if status & 0x00001000:      # PRINTER_STATUS_NOT_AVAILABLE
                return "Offline"
            if status & (0x00000002 | 0x00000008 | 0x00000010 | 0x00004000):
                return "Error"
            return "Online"
        finally:
            win32print.ClosePrinter(handle)
    except Exception as e:
        logger.error(f"win32print handle check failed for '{printer_name}': {e}")
        return "Offline"


def _get_usb_port(printer_name: str):
    if _OS == "Darwin":
        return _macos_get_port(printer_name)
    if not _WIN32_AVAILABLE:
        return None
    try:
        handle = win32print.OpenPrinter(printer_name)
        try:
            return win32print.GetPrinter(handle, 2).get("pPortName")
        finally:
            win32print.ClosePrinter(handle)
    except Exception as e:
        logger.error(f"Failed to get USB port for '{printer_name}': {e}")
        return None


def print_direct(port_name: str, data: bytes) -> bool:
    if _OS == "Darwin":
        return _macos_print_direct(port_name, data)
    try:
        device_path = f"\\\\.\\{port_name}"
        logger.info(f"Direct write to {device_path} ({len(data)} bytes)")
        with open(device_path, "wb") as f:
            f.write(data)
        return True
    except Exception as e:
        logger.error(f"Direct print to {port_name} failed: {e}")
        return False


def print_raw(printer_name: str, data: bytes) -> bool:
    if _OS == "Darwin":
        return _macos_print_raw(printer_name, data)
    if not _WIN32_AVAILABLE:
        logger.error("win32print not available")
        return False
    try:
        handle = win32print.OpenPrinter(printer_name)
        job = win32print.StartDocPrinter(handle, 1, ("Agent Job", None, "RAW"))
        win32print.StartPagePrinter(handle)
        win32print.WritePrinter(handle, data)
        win32print.EndPagePrinter(handle)
        win32print.EndDocPrinter(handle)
        win32print.ClosePrinter(handle)
        return True
    except Exception as e:
        logger.error(f"Spooler print failed for '{printer_name}': {e}")
        return False


# ── Background loops ──────────────────────────────────────────────────────────

def heartbeat_loop():
    hostname = socket.gethostname()
    while True:
        try:
            _http_post(
                f"{SERVER_URL}/agent/heartbeat",
                params={"agent_id": AGENT_ID, "token": TOKEN,
                        "location_id": LOCATION_ID, "hostname": hostname},
                timeout=5,
                verify=_TLS_VERIFY,
            )
        except Exception as e:
            logger.debug(f"Heartbeat failed: {e}")
        time.sleep(HEARTBEAT_INTERVAL)


def status_reporting_loop():
    logger.info("Status reporting loop started")
    mapped_printers: list = []
    last_config_sync = 0

    while True:
        try:
            # Sync printer list from server every 5 minutes
            if time.time() - last_config_sync > 300:
                try:
                    res = _http_get(
                        f"{SERVER_URL}/agent/config",
                        params={"agent_id": AGENT_ID, "token": TOKEN, "location_id": LOCATION_ID},
                        timeout=10,
                        verify=_TLS_VERIFY,
                    )
                    if res.status_code == 200:
                        mapped_printers = res.json().get("printers", [])
                        logger.info(f"Synced config. Mapped printers: {mapped_printers}")
                        last_config_sync = time.time()
                    elif res.status_code == 401:
                        logger.error("Config sync: Unauthorized — token may be invalid")
                except Exception as e:
                    logger.warning(f"Config sync failed: {e}")

            # On Windows: check _WIN32_AVAILABLE, not the module itself
            if _OS == "Windows" and not _WIN32_AVAILABLE:
                time.sleep(60)
                continue

            # Enumerate local printers
            if _OS == "Darwin":
                local_printers = {p: {} for p in _macos_list()}
            elif _WIN32_AVAILABLE:
                local_printers = {p[2]: p for p in win32print.EnumPrinters(2)}
            else:
                time.sleep(60)
                continue

            # Report status for each mapped printer
            for p_name in mapped_printers:
                if p_name in local_printers:
                    status = check_printer_status(p_name)
                else:
                    status = "Offline"
                    logger.warning(f"Mapped printer '{p_name}' NOT found locally")

                try:
                    _http_post(
                        f"{SERVER_URL}/agent/printer-status",
                        params={"agent_id": AGENT_ID, "token": TOKEN},
                        json={"printer_name": p_name, "status": status},
                        timeout=5,
                        verify=_TLS_VERIFY,
                    )
                    logger.debug(f"Reported '{p_name}' → {status}")
                except Exception as e:
                    logger.warning(f"Status report failed for '{p_name}': {e}")

        except Exception as e:
            logger.error(f"Status reporting loop error: {e}")

        time.sleep(15)


def agent_loop():
    logger.info(f"Agent {AGENT_ID} running | Server: {SERVER_URL} | TLS verify: {_TLS_VERIFY}")

    threading.Thread(target=heartbeat_loop, daemon=True).start()
    threading.Thread(target=status_reporting_loop, daemon=True).start()

    while True:
        success = False
        try:
            response = _http_get(
                f"{SERVER_URL}/agent/jobs",
                params={"agent_id": AGENT_ID, "token": TOKEN, "location_id": LOCATION_ID},
                timeout=10,
                verify=_TLS_VERIFY,
            )

            if response.status_code == 200:
                jobs = response.json()
                success = True  # successful poll even if no jobs
                for job in jobs:
                    _process_job(job)

            elif response.status_code == 401:
                logger.error("Authentication failed — re-run setup with a new activation code")
                time.sleep(30)
                success = True  # don't backoff further; this is a config error

        except requests.exceptions.ConnectionError as e:
            logger.warning(f"Cannot reach server: {e}")
        except requests.exceptions.Timeout:
            logger.warning("Poll request timed out")
        except Exception as e:
            logger.error(f"Polling error: {e}")

        _backoff_sleep(success)


def _process_job(job):
    """Download and print a single job."""
    jid = job["id"]
    printer = job["printer"]
    logger.info(f"[JOB] ID={jid} Printer={printer} Priority={job.get('priority')}")

    # Download with 3 retries
    content = None
    for attempt in range(3):
        try:
            with _session.get(
                f"{SERVER_URL}/agent/job/{jid}/file",
                params={"agent_id": AGENT_ID, "token": TOKEN},
                stream=True,
                timeout=60,
                verify=_TLS_VERIFY,
            ) as r:
                r.raise_for_status()
                expected_size = int(r.headers.get("Content-Length", 0)) or None
                buf = bytearray()
                for chunk in r.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        buf.extend(chunk)
                if not buf:
                    raise ValueError("Empty file received")
                if expected_size and len(buf) != expected_size:
                    raise ValueError(f"Partial download: expected {expected_size}, got {len(buf)}")
                content = bytes(buf)
                logger.info(f"[DOWNLOAD] ID={jid} size={len(content)} bytes")
                break
        except Exception as e:
            logger.warning(f"[DOWNLOAD] Attempt {attempt+1}/3 failed: {e}")
            if attempt < 2:
                time.sleep(2 ** attempt)

    if content is None:
        logger.error(f"[DOWNLOAD FAILED] Job {jid} — leaving for lease expiry recovery")
        return

    # Validate printer status before printing
    time.sleep(0.5)
    current_status = check_printer_status(printer)
    if current_status != "Online":
        logger.error(f"[ABORT] Job {jid}: Printer '{printer}' is {current_status}")
        try:
            _http_post(
                f"{SERVER_URL}/agent/fail",
                params={"job_id": jid, "agent_id": AGENT_ID, "token": TOKEN,
                        "error": f"Printer is {current_status}"},
                timeout=5,
                verify=_TLS_VERIFY,
            )
        except Exception:
            pass
        return

    # Print: try direct port first, fall back to spooler
    printed = False
    port_name = _get_usb_port(printer)
    if port_name and (port_name.upper().startswith("USB") or port_name.upper().startswith("COM")):
        if print_direct(port_name, content):
            time.sleep(1)
            post_status = check_printer_status(printer)
            if post_status != "Error":
                logger.info(f"[SUCCESS] Job {jid} via direct port {port_name}")
                printed = True
            else:
                logger.warning(f"[FALLBACK] Post-print error on {port_name}, trying spooler")

    if not printed:
        if print_raw(printer, content):
            logger.info(f"[SUCCESS] Job {jid} via spooler")
            printed = True

    # Confirm or fail
    try:
        if printed:
            conf = _http_post(
                f"{SERVER_URL}/agent/confirm",
                params={"job_id": jid, "agent_id": AGENT_ID, "token": TOKEN},
                timeout=15,
                verify=_TLS_VERIFY,
            )
            if conf.status_code == 200:
                logger.info(f"[CONFIRMED] Job {jid}")
            else:
                logger.error(f"[CONFIRM FAIL] Job {jid}: {conf.status_code}")
        else:
            _http_post(
                f"{SERVER_URL}/agent/fail",
                params={"job_id": jid, "agent_id": AGENT_ID, "token": TOKEN,
                        "error": "Hardware print failure"},
                timeout=5,
                verify=_TLS_VERIFY,
            )
            logger.error(f"[FAILED] Job {jid}")
    except Exception as e:
        logger.error(f"[CONFIRM/FAIL REQUEST ERROR] Job {jid}: {e}")


if __name__ == "__main__":
    agent_loop()
