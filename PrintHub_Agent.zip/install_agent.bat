@echo off
setlocal EnableDelayedExpansion
:: ============================================================
:: PrintHub Agent Installer for Windows
:: Must be run as Administrator
:: ============================================================
cd /d "%~dp0"

echo.
echo  =====================================================
echo    PrintHub USB Print Agent  ^|  Windows Installer
echo  =====================================================
echo.

:: ── Check for Administrator privileges ──────────────────────
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo  [ERROR] Please right-click this file and choose
    echo          "Run as Administrator"
    echo.
    pause
    exit /b 1
)
echo  [OK] Running with Administrator privileges.

:: ── Check Python ─────────────────────────────────────────────
python --version >nul 2>&1
if %errorLevel% NEQ 0 (
    echo.
    echo  [ERROR] Python is not installed or not in PATH.
    echo  Download Python 3.9+ from https://www.python.org/downloads/
    echo  IMPORTANT: Check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)
echo  [OK] Python found.

:: ── Create virtual environment ───────────────────────────────
if not exist "venv" (
    echo  [1/4] Creating virtual environment...
    python -m venv venv
    if %errorLevel% NEQ 0 (
        echo  [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)
echo  [OK] Virtual environment ready.

:: ── Install dependencies ─────────────────────────────────────
echo  [2/4] Installing dependencies...
call .\venv\Scripts\activate.bat
pip install --quiet -r requirements.txt
if %errorLevel% NEQ 0 (
    echo  [ERROR] pip install failed.
    pause
    exit /b 1
)
echo  [OK] Dependencies installed.

:: ── Register (first run only) ────────────────────────────────
if not exist "agent_config.json" (
    echo.
    echo  [3/4] First-time setup
    echo  ─────────────────────────────────────────────────────
    echo  The agent connects to your PrintHub server using
    echo  OUTBOUND HTTP/HTTPS only. No inbound firewall rules
    echo  are needed on this workstation.
    echo  ─────────────────────────────────────────────────────
    echo.
    set /p SERVER_IP="  Enter Server IP or hostname (e.g. 192.168.1.50): "
    set /p SERVER_PORT="  Enter Server Port (press Enter for 8000): "
    if "!SERVER_PORT!"=="" set SERVER_PORT=8000

    set /p USE_HTTPS="  Use HTTPS? (y/N): "
    if /I "!USE_HTTPS!"=="y" (
        set PROTOCOL=https
    ) else (
        set PROTOCOL=http
    )

    set /p ACT_CODE="  Enter Activation Code from Dashboard: "
    set ACT_CODE=!ACT_CODE: =!

    echo.
    echo  Registering with !PROTOCOL!://!SERVER_IP!:!SERVER_PORT!...
    python agent_setup.py --code !ACT_CODE! --server !PROTOCOL!://!SERVER_IP!:!SERVER_PORT!
    if %errorLevel% NEQ 0 (
        echo  [ERROR] Setup failed. Check activation code and server address.
        pause
        exit /b 1
    )
) else (
    echo  [3/4] Already configured — skipping registration.
)

:: ── Install and start Windows Service ────────────────────────
echo  [4/4] Installing Windows Service...
python agent_service.py --startup auto install
if %errorLevel% NEQ 0 (
    echo  [WARN] Service install returned an error (may already be installed).
)

echo  Starting service...
python agent_service.py start
if %errorLevel% NEQ 0 (
    echo  [WARN] Service start returned an error. Check Windows Event Viewer.
)

:: ── Done ─────────────────────────────────────────────────────
echo.
echo  =====================================================
echo    SUCCESS! PrintHub Agent is running.
echo.
echo    The service starts automatically on every boot.
echo    Logs: C:\PrintHubAgent\printhub_agent.log
echo.
echo    Firewall note:
echo    This agent uses OUTBOUND connections only.
echo    Allow port 8000 (or 443 for HTTPS) outbound in
echo    Windows Defender Firewall for the server IP.
echo  =====================================================
echo.
pause
