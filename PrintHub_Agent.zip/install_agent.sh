#!/bin/bash
# ============================================================
# PrintHub Agent Installer for macOS
# ============================================================
# This script installs the agent as a LaunchAgent (per-user)
# that starts automatically at login and stays running.
#
# Firewall note: the agent makes OUTBOUND HTTP/HTTPS requests
# only. No inbound rules are required on this Mac.
# ============================================================

set -e  # Exit on error

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

PLIST_PATH="$HOME/Library/LaunchAgents/com.printhub.agent.plist"
LOG_DIR="$HOME/Library/Logs"
LOG_FILE="$LOG_DIR/printhub_agent.log"

echo ""
echo " ====================================================="
echo "   PrintHub USB Print Agent  |  macOS Installer"
echo " ====================================================="
echo ""

# ── Check Python 3 ────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo " [ERROR] Python 3 is not installed."
    echo " Install via: brew install python"
    echo " Or download from: https://www.python.org/downloads/macos/"
    exit 1
fi
PY_VER=$(python3 -c "import sys; print(sys.version_info[:2])")
echo " [OK] Python 3 found: $(python3 --version)"

# ── Check CUPS (lpstat) ───────────────────────────────────────
if ! command -v lpstat &>/dev/null; then
    echo " [WARN] lpstat not found. Install Xcode Command Line Tools:"
    echo "        xcode-select --install"
fi

# ── Virtual environment ───────────────────────────────────────
if [ ! -d "venv" ]; then
    echo " [1/4] Creating virtual environment..."
    python3 -m venv venv
fi
echo " [OK] Virtual environment ready."

# ── Install dependencies ──────────────────────────────────────
echo " [2/4] Installing dependencies..."
source venv/bin/activate
pip install --quiet -r requirements.txt
echo " [OK] Dependencies installed."

# ── Restrict config file permissions ─────────────────────────
if [ -f "agent_config.json" ]; then
    chmod 600 agent_config.json
fi

# ── First-time registration ───────────────────────────────────
if [ ! -f "agent_config.json" ]; then
    echo ""
    echo " [3/4] First-time setup"
    echo " ─────────────────────────────────────────────────────"
    echo " The agent connects via OUTBOUND HTTP/HTTPS only."
    echo " No inbound firewall rules are needed on this Mac."
    echo " ─────────────────────────────────────────────────────"
    echo ""
    read -rp "  Enter Server IP or hostname (e.g. 192.168.1.50): " SERVER_IP
    read -rp "  Enter Server Port (press Enter for 8000): " SERVER_PORT
    SERVER_PORT="${SERVER_PORT:-8000}"

    read -rp "  Use HTTPS? (y/N): " USE_HTTPS
    if [[ "${USE_HTTPS,,}" == "y" ]]; then
        PROTOCOL="https"
    else
        PROTOCOL="http"
    fi

    read -rp "  Enter Activation Code from Dashboard: " ACT_CODE
    ACT_CODE="${ACT_CODE// /}"  # strip spaces

    echo ""
    echo " Registering with ${PROTOCOL}://${SERVER_IP}:${SERVER_PORT}..."
    python3 agent_setup.py --code "$ACT_CODE" --server "${PROTOCOL}://${SERVER_IP}:${SERVER_PORT}"
    chmod 600 agent_config.json
else
    echo " [3/4] Already configured — skipping registration."
fi

# ── Create LaunchAgent plist ──────────────────────────────────
echo " [4/4] Configuring background service..."
mkdir -p "$HOME/Library/LaunchAgents"

cat > "$PLIST_PATH" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.printhub.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>${DIR}/venv/bin/python3</string>
        <string>${DIR}/agent.py</string>
    </array>
    <key>WorkingDirectory</key>
    <string>${DIR}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>ThrottleInterval</key>
    <integer>10</integer>
    <key>StandardOutPath</key>
    <string>${LOG_FILE}</string>
    <key>StandardErrorPath</key>
    <string>${LOG_FILE}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    </dict>
</dict>
</plist>
PLIST

chmod 644 "$PLIST_PATH"

# ── Load the service ──────────────────────────────────────────
launchctl unload "$PLIST_PATH" 2>/dev/null || true
launchctl load "$PLIST_PATH"

# ── Done ─────────────────────────────────────────────────────
echo ""
echo " ====================================================="
echo "   SUCCESS! PrintHub Agent is running."
echo ""
echo "   The service starts automatically at every login."
echo "   Logs: ${LOG_FILE}"
echo ""
echo "   Manage the service:"
echo "   Stop : launchctl unload ${PLIST_PATH}"
echo "   Start: launchctl load   ${PLIST_PATH}"
echo "   Status: launchctl list | grep printhub"
echo ""
echo "   Firewall note:"
echo "   Allow outbound port 8000 (or 443 for HTTPS) to"
echo "   the PrintHub server in System Preferences > Security."
echo " ====================================================="
echo ""
