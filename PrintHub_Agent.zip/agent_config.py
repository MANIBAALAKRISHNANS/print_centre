"""
PrintHub Agent Configuration Manager

Config is stored in agent_config.json in the same directory as the agent.
On first run, only the activation code and server URL are written.
After successful registration, full credentials are saved and file permissions
are restricted so only the running user can read the token.
"""

import json
import os
import platform
import stat

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_config.json")
_OS = platform.system()


def load_config() -> dict:
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def save_config(data: dict):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    restrict_config_permissions()


def restrict_config_permissions():
    """Restrict config file so only the owner can read it (Unix: chmod 600)."""
    if not os.path.exists(CONFIG_PATH):
        return
    if _OS in ("Darwin", "Linux"):
        try:
            os.chmod(CONFIG_PATH, stat.S_IRUSR | stat.S_IWUSR)  # 600
        except Exception:
            pass
    elif _OS == "Windows":
        # On Windows, use icacls to remove group/other read access
        try:
            import subprocess
            username = os.environ.get("USERNAME", "")
            if username:
                subprocess.run(
                    ["icacls", CONFIG_PATH, "/inheritance:r",
                     "/grant:r", f"{username}:(R,W)"],
                    capture_output=True, check=False
                )
        except Exception:
            pass


def is_first_run() -> bool:
    config = load_config()
    return not (config.get("agent_id") and config.get("token"))


def write_pending_registration(activation_code: str, server_url: str, tls_verify: bool = True):
    """Write activation code + server URL for ensure_registered() to pick up."""
    config = load_config()
    config.update({
        "pending_activation_code": activation_code,
        "server_url": server_url.rstrip("/"),
        "tls_verify": tls_verify,
    })
    save_config(config)
