#!/usr/bin/env python3
"""
PrintHub Agent Setup Tool
Run this ONCE on each workstation before starting the agent service.

Usage examples:
  python agent_setup.py --code A3F9B2C1 --server http://192.168.1.50:8000
  python agent_setup.py --code A3F9B2C1 --server https://printhub.hospital.internal
  python agent_setup.py --code A3F9B2C1 --server https://printhub.hospital.internal --no-verify
  python agent_setup.py --status
  python agent_setup.py --reset
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agent_config import write_pending_registration, load_config, is_first_run, CONFIG_PATH


def main():
    parser = argparse.ArgumentParser(
        description="PrintHub Agent Setup",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python agent_setup.py --code A3F9B2C1 --server http://192.168.1.50:8000
  python agent_setup.py --code A3F9B2C1 --server https://printhub.hospital.internal
  python agent_setup.py --status
  python agent_setup.py --reset
""",
    )
    parser.add_argument("--code", metavar="CODE",
                        help="8-character activation code from the PrintHub dashboard")
    parser.add_argument("--server", default="http://127.0.0.1:8000", metavar="URL",
                        help="PrintHub server URL (default: http://127.0.0.1:8000)")
    parser.add_argument("--no-verify", action="store_true",
                        help="Disable TLS certificate verification (for self-signed certs)")
    parser.add_argument("--status", action="store_true",
                        help="Show current registration status")
    parser.add_argument("--reset", action="store_true",
                        help="Clear saved credentials (allows re-registration)")
    args = parser.parse_args()

    if args.status:
        config = load_config()
        if config.get("agent_id"):
            print(f"Registered : {config['agent_id']}")
            print(f"Location   : {config.get('location_id', '(unknown)')}")
            print(f"Server     : {config.get('server_url')}")
            print(f"TLS verify : {config.get('tls_verify', True)}")
            print(f"Config file: {CONFIG_PATH}")
        else:
            print("Not registered.")
            print("Run: python agent_setup.py --code YOUR_CODE --server http://SERVER_IP:8000")
        return

    if args.reset:
        if os.path.exists(CONFIG_PATH):
            os.remove(CONFIG_PATH)
            print("Credentials cleared. Run setup again with a new activation code.")
        else:
            print("Nothing to reset — no config file found.")
        return

    if not args.code:
        parser.print_help()
        sys.exit(1)

    code = args.code.strip().upper()
    if len(code) != 8:
        print(f"ERROR: Activation code must be exactly 8 characters (got {len(code)})")
        sys.exit(1)

    if not is_first_run():
        print("Agent is already registered.")
        print("To re-register, run: python agent_setup.py --reset")
        sys.exit(1)

    tls_verify = not args.no_verify
    server_url = args.server.rstrip("/")

    write_pending_registration(code, server_url, tls_verify)

    print(f"Activation code saved.")
    print(f"Server     : {server_url}")
    print(f"TLS verify : {tls_verify}")
    print()
    if not tls_verify:
        print("WARNING: TLS verification is disabled. Only use this for trusted internal networks.")
        print()
    print("Next steps:")
    print("  Windows : python agent_service.py start")
    print("  macOS   : launchctl load ~/Library/LaunchAgents/com.printhub.agent.plist")
    print()
    print("The agent will register automatically on first start.")


if __name__ == "__main__":
    main()
